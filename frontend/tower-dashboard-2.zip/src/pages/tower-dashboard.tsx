import React from 'react';

export default function TowerDashboard() {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold text-black">Tower Dashboard</h1>
      <p>This is a simple dashboard view.</p>
    </div>
  );
}
